<?php
//database_connection.php

$connect = new PDO('mysql:host=localhost:3306;dbname=testing2', 'root', '');
session_start();

?>